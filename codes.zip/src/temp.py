import time
from multiprocessing import Pool



if __name__ == "__main__":

    pool = Pool(3)  # 创建拥有3个进程数量的进程池
